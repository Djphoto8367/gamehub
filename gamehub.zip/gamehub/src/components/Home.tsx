import { useState } from "react";
import NavBar from "./NavBar";
import GameGrid from "./GameGrid";

const Exercise = () => {
    const [DarkMode,setDarkMode] = useState(false)
    const changeMode = (value:boolean) => {
        setDarkMode(value)
    }
    return(
        <>
            <div className={`container-xxl ${DarkMode?'dark-mode':'white-mode'}`}>
                <div className="row">
                    <div className="col-12">
                        <NavBar ChangeMode={changeMode}/>
                    </div>
                </div>
                <div className="row">
                    <div className="col d-none d-lg-block bg-success">side bar</div>
                    <div className="col bg-secondary">
                        <GameGrid />
                    </div>
                </div>
            </div>
        </>
    )
}

export default Exercise;