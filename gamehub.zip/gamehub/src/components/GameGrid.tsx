import { useEffect, useState } from 'react'
import apiService from '../services/api-client'

interface Games {
    id:number,
    name:string
}

interface GamesGroup {
    count:number,
    results:Games[]
}

const GameGrid = () => {
    const [games,setGames] = useState<Games[]>([])
    const [error,setError] = useState('')

    useEffect(()=>{
        apiService.get<GamesGroup>('/games')
            .then(res=>setGames(res.data.results))
            .catch(err => setError(err.message))
    })
    return(
        <>
            {error && <p>{error}</p>}
            <ul>
                {games.map(game => <li>{game.name}</li>)}
            </ul>
        </>
    )
}

export default GameGrid