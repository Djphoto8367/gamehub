import Exercise from "./components/Home"

const App = () => {
  return(
    <Exercise />
  )
}

export default App